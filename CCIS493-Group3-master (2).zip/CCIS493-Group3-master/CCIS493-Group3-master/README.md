# HaircutBookingSystem
UserStory1 - Complete with exceptions:
  - No Database
  - No SMTP Service
